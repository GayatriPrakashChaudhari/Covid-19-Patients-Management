function checkAdminLog(){
    var adminLogemail = $("#adminLogemail").val();
    var adminLogpass = $("#adminLogpass").val();
    $.ajax({
        url:'Admin/admin.php',
        method : "POST",
        data:{
            checklogemail: "checklogemail",
            adminLogpass   : adminLogpass,
            adminLogemail  : adminLogemail,
        },
        success:function(data){
            if(data == 0){
                $("#statusAdminLogMsg").html('<small class = "alert alert-danger">Invalid Email Id or Password</small>');
                // setTimeout(()=>{window.location.href = "Admin/adminDashboard.php";},1000);
            }
           else if(data == 1){
                $("$statusAdminLogMsg").html('<div class = "spinner-border text-success" role="status">Login Successful</div>');
                setTimeout(() =>{
                    window.location.href = "index.php";
                },1000);
               }

        },
    });
}
