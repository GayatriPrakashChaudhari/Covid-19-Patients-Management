<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Bootsrap css -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
   <!-- custom css -->
  <link rel="stylesheet" href="css/style.css">

  <title>covid-19patientsmanagement.com</title>
</head>

<body>

  <!-- navigation starts here -->
  <nav class="navbar navbar-expand-sm navbar-dark bg-dark pl-5 fixed-top">
    <a class="navbar-brand" href="index.php">Covid-19</a>
    <span class="navbar-text">Patients Management</span>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav custom-nav pl-5">
        <li class="nav-item custom-nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item custom-nav-item"><a class="nav-link" href="admin.php">Admin</a></li>
        
      </ul>
    </div>
  </nav>
  <!-- navigation eneds here -->