<!-- footer section starts here -->
<footer class="container-fluid bg-dark text-center p-2">
    <small class="text-white">Copyright &copy; 2021 || Designed By, Gayatri Chaudhari ||</small>
  </footer>
  <!-- footer section ends here -->

  <!-- jquery javascript -->
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <!-- bootstrap javascript -->
  <script src="js/bootstrap.min.js"></script>
  
  <!--Admin ajax call javascript -->
  <script type="text/javascript" src="js/adminajaxrequest.js"></script>
</body>

</html>