<!-- jquery and bootstrap javasript -->
<script type="text/javascript" src="./js/jquery.min.js"></script>
<script type="text/javascript" src="./js/popper.min.js"></script>
<script type="text/javascript" src="./js/bootstrap.min.js"></script>

<!-- font Awesom javascript -->
<script type="text/javascript" src="./js/all.min.js"></script>
<!-- Admin Ajax call Javascript -->
<script type="text/javascript" src="./js/adminajaxrequest.js"></script>

<!-- custom javascript -->
<script type="text/javascript" src="./js/custom.js"></script>

</html>