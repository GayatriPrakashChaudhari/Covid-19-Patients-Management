<!-- header starts here -->
<?php
include('./mainInclude/header.php');
include('dbconnection.php')
?>
<!-- header ends here -->
<!-- background start here -->
<div class="container-field remove-vid-marg">
    <img src="images/one.jpg" alt="">
  </div>
  <!-- background ends here -->


<!-- including footer from footer.php file -->
<?php
include('./mainInclude/footer.php');
?>
<!-- including footer from footer.php file -->