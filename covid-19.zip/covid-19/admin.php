<?php
include('./header.php');
include('./dbconnection.php')
?>
<!-- header ends here -->
<style>
  body{
      background-image: url("./images/two.jpg");
      background-repeat: no-repeat;
      background-size: 100%;
  }
  div{
      margin-top: 15%;
      margin-left: 30%;
  }
  small{
    margin-top: 15%;
      margin-left: 20%;
  }
</style>
<body>


  <!-- middle content of page starts here -->
  <div class="vid-content">
    <h1 class="my-content">Admin Management Dashboard</h1>
    <small class="my-content">Welcome To Covid-19 Patients Management </small><br>
  </div>
</body>
<!-- including footer from footer.php file -->
<?php
include('./footer.php');
?>
<!-- including footer from footer.php file -->